import { random } from "lodash";

export const getRandomColor = () =>
  `rgb(${random(255)},${random(255)},${random(255)})`;

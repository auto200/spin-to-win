export const theme = {
  colors: {
    primary: "#000",
    secondary: "#fff",
  },
};

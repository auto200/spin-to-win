import styled from "styled-components";

const Wrapper = styled.li.attrs(({ bgColor }) => ({
  style: {
    backgroundColor: bgColor,
  },
}))`
  width: 100%;
  height: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Two = ({ items }) => {
  return items.map(({ id, text, bgColor }) => (
    <Wrapper key={id} bgColor={bgColor}>
      {text}
    </Wrapper>
  ));
};

export default Two;

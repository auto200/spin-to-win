import styled from "styled-components";

const Wrapper = styled.li.attrs(({ bgColor, i, rotateAngle }) => ({
  style: {
    backgroundColor: bgColor,
    transform: `rotate(${i * rotateAngle}deg) skewY(30deg)`,
  },
}))`
  position: absolute;
  top: -10%;
  right: -10%;
  width: 60%;
  height: 60%;
  transform-origin: 0% 100%;
  text-align: center;
`;
const Text = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform: skewY(-30deg) rotate(${({ i }) => i * -120}deg);
  display: flex;
  align-items: center;
  justify-content: center;
  right: 10%;
`;
const Three = ({ items }) => {
  return items.map(({ id, text, bgColor }, i) => (
    <Wrapper key={id} bgColor={bgColor} i={i} rotateAngle={360 / items.length}>
      <Text i={i}>{text.toString().slice(10).trim()}</Text>
    </Wrapper>
  ));
};

export default Three;

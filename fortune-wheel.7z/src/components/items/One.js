import styled from "styled-components";

const Wrapper = styled.li.attrs(({ bgColor }) => ({
  style: {
    backgroundColor: bgColor,
  },
}))`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const One = ({ text, bgColor }) => {
  return <Wrapper bgColor={bgColor}>{text}</Wrapper>;
};

export default One;

import styled from "styled-components";

const Wrapper = styled.li.attrs(({ bgColor, i, rotateAngle }) => ({
  style: {
    backgroundColor: bgColor,
    transform: `rotate(${i * rotateAngle}deg) skewY(-${Math.abs(
      90 - rotateAngle
    )}deg)`,
  },
}))`
  overflow: hidden;
  position: absolute;
  top: 0;
  right: 0;
  width: 50%;
  height: 50%;
  transform-origin: 0% 100%;
`;
const Text = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  transform: skewY(-30deg) rotate(-120deg);
  display: flex;
  align-items: center;
  justify-content: center;
  right: 10%;
  writing-mode: vertical-rl;
  text-orientation: mixed;
`;
const MoreThanThree = ({ items }) => {
  return items.map(({ id, text, bgColor }, i) => (
    <Wrapper key={id} i={i} rotateAngle={360 / items.length} bgColor={bgColor}>
      <Text>{text}</Text>
    </Wrapper>
  ));
};

export default MoreThanThree;

import { useEffect, useState } from "react";
import styled from "styled-components";
import { getRandomColor } from "./utils";
import One from "./components/items/One";
import TwoItems from "./components/items/Two";
import ThreeItems from "./components/items/Three";
import MoreThanThreeItems from "./components/items/MoreThanThree";
import { random, rangeRight } from "lodash";

const Circle = styled.ul.attrs(({ spin }) => ({
  style: {
    transform: `rotate(${spin}deg)`,
    transition: `transform ${random(3, 6)}s ease-in-out`,
  },
}))`
  position: relative;
  border: 1px solid ${({ theme }) => theme.colors.primary};
  padding: 0;
  margin: 1em auto;
  width: 20em;
  height: 20em;
  border-radius: 50%;
  list-style: none;
  overflow: hidden;
`;

function CircleItems({ items }) {
  if (!items.length) {
    return <One bgColor={getRandomColor()} text="ty no nie wiem" />;
  }
  if (items.length === 1) {
    return <One bgColor={items[0].bgColor} text={items[0].text} />;
  }
  if (items.length === 2) {
    return <TwoItems items={items} />;
  }
  if (items.length === 3) {
    return <ThreeItems items={items} />;
  }
  return <MoreThanThreeItems items={items} />;
}
//https://stackoverflow.com/questions/29006214/how-to-divide-a-circle-into-12-equal-parts-with-color-using-css3-javascript
//IDEA: maby could use liblary like d3js or *c3js* to display the pie, i think it would be much easier but what about image as a background then?
//TODO: figure out how to pick a winner
function App() {
  const [items, setItems] = useState(
    Array(2)
      .fill(null)
      .map(() => ({
        id: Math.random(),
        text: Math.random().toString().slice(0, 5),
        bgColor: getRandomColor(),
      }))
  );
  const [ranges, setRanges] = useState([]);
  const [rotation, setRotation] = useState(0);

  const spin = () => {
    setRotation(random(720, 4320));
  };
  const inWhatRange = (number) => {
    return ranges.findIndex((num) => num < number);
  };

  console.log("ranges", ranges);
  useEffect(() => {
    setRanges(rangeRight(0, 360, 360 / items.length));
  }, [items.length]);

  useEffect(() => {
    console.log(rotation % 360, rotation / 360);
  }, [rotation]);

  return (
    <>
      <Circle
        spin={rotation}
        onTransitionEnd={() => {
          const index = inWhatRange(rotation % 360);
          console.log(index);
          const tmpItems = [...items];
          tmpItems[index].text = "winner!!";
          setItems(tmpItems);
        }}
      >
        <CircleItems items={items} />
      </Circle>
      <button onClick={spin}>spin the weel</button>
    </>
  );
}

export default App;
